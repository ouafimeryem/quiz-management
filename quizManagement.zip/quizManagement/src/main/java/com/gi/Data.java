package com.gi;

public class Data {
    public static String text = "" ;
    public static String note = "" ;
}
